set(sources
	main.cpp
)
