
ArmorAddon[] Function GetArmorAddons() native
