#include "f4se/GameMessages.h"

// 
RelocPtr <BSTCommonScrapHeapMessageQueue<BSPackedTask>*> g_messageQueue(0x032FF808);
